Imports Krystalware.SlickUpload
Imports Krystalware.SlickUpload.Web.Controls

Namespace Validation
    Public Class ValidationDefault
        Inherits System.Web.UI.Page

        
        Protected Sub slickUpload_UploadComplete(ByVal sender As Object, ByVal e As UploadSessionEventArgs) Handles slickUpload.UploadComplete
            uploadResultPanel.Visible = True
            uploadPanel.Visible = False

            If Not e.UploadSession Is Nothing AndAlso e.UploadSession.State = UploadState.Complete Then
                If e.UploadSession.UploadedFiles.Count > 0 Then
                    
                    resultsRepeater.DataSource = e.UploadSession.UploadedFiles
                    resultsRepeater.DataBind()
                End If
            End If
        End Sub

        Protected Sub newUploadButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles newUploadButton.Click
            uploadResultPanel.Visible = False
            uploadPanel.Visible = True
        End Sub
        

        
        Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
            Dim maxFiles As Integer
            Dim maxFileSize As Integer

            If Integer.TryParse(maxFilesTextBox.Text, maxFiles) Then
                slickUpload.MaxFiles = maxFiles
            End If

            If Integer.TryParse(maxFileSizeTextBox.Text, maxFileSize) Then
                slickUpload.MaxFileSize = maxFileSize
            End If

            slickUpload.ConfirmNavigateDuringUploadMessage = confirmNavigateMessageTextBox.Text
            slickUpload.ValidExtensions = validExtensionsTextBox.Text
            slickUpload.InvalidExtensionMessage = fileTypeMessageTextBox.Text
            slickUpload.InvalidFileSizeMessage = fileSizeMessageTextBox.Text

            requiredFilesValidator.Enabled = requireFileSelectionCheckBox.Checked

            summaryValidator.Text = summaryMessageTextBox.Text
            summaryValidator.Enabled = Not allowInvalidUploadCheckBox.Checked
        End Sub


    End Class
End Namespace

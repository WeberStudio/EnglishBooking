Imports Krystalware.SlickUpload

Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Public Function Index(session As UploadSession) As ActionResult
        Return View(session)
    End Function
End Class
